package com.aliucord.plugins.otimizador

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.aliucord.Constants
import com.aliucord.Utils
import com.aliucord.api.SettingsAPI
import com.aliucord.fragments.SettingsPage
import com.aliucord.utils.DimenUtils.dp
import com.aliucord.views.Button
import com.aliucord.views.Divider
import com.discord.views.CheckedSetting

/**
 * Painel de configurações nativo do OtimizadorChatPro
 * Utiliza o design kit nativo do Discord/Aliucord sem dependências externas.
 */
class PluginSettings(private val settings: SettingsAPI) : SettingsPage() {

    override fun onViewBound(view: View) {
        super.onViewBound(view)
        setActionBarTitle("OtimizadorChatPro")
        setActionBarSubtitle("Configurações de Desempenho e Mídia")

        val ctx = requireContext()
        val layout = linearLayout

        // Cabeçalho Mensagens
        layout.addView(createSectionHeader(ctx, "MENSAGENS & DESEMPENHO DA UI"))

        // Toggle: Otimização de Mensagens
        layout.addView(
            createSwitch(
                ctx,
                "Otimizar Envio de Mensagens",
                "Evita travamentos da thread principal e previne reenvios acidentais por clique duplo.",
                "opt_msg_enabled",
                true
            )
        )

        // Toggle: Limpeza proativa de bitmaps
        layout.addView(
            createSwitch(
                ctx,
                "Gerenciamento Proativo de Memória",
                "Recicla bitmaps e buffers temporários imediatamente após o envio para evitar travamentos de GC.",
                "opt_memory_gc",
                true
            )
        )

        layout.addView(Divider(ctx))

        // Cabeçalho Imagens
        layout.addView(createSectionHeader(ctx, "PROCESSAMENTO DE IMAGENS"))

        // Toggle: Otimizar Imagens
        layout.addView(
            createSwitch(
                ctx,
                "Ativar Otimização de Imagens",
                "Redimensiona e comprime imagens localmente antes do upload, acelerando o envio em conexões lentas.",
                "opt_img_enabled",
                true
            )
        )

        // Qualidade da Compressão
        val currentQuality = settings.getInt("opt_img_quality", 85)
        layout.addView(
            createSwitch(
                ctx,
                "Compressão Balanceada ($currentQuality% Qualidade)",
                "Reduz o tamanho em até 80% sem perda visível no feed do Discord. Alternar altera entre 85% e 92%.",
                "opt_img_high_quality",
                currentQuality >= 88
            ) { checked ->
                settings.setInt("opt_img_quality", if (checked) 90 else 85)
            }
        )

        // Dimensões Máximas
        val maxDim = settings.getInt("opt_img_max_dim", 1600)
        layout.addView(
            createSwitch(
                ctx,
                "Limite Máximo de Resolução ($maxDim px)",
                "Redimensiona imagens maiores que $maxDim px mantendo a proporção original. Alterna entre 1600px e 2048px.",
                "opt_img_res_limit",
                maxDim >= 1920
            ) { checked ->
                settings.setInt("opt_img_max_dim", if (checked) 2048 else 1600)
            }
        )

        layout.addView(Divider(ctx))

        // Botão Restaurar Padrões
        val btnReset = Button(ctx).apply {
            text = "Restaurar Configurações Padrão"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 16.dp, 0, 16.dp)
            }
            setOnClickListener {
                settings.setBool("opt_msg_enabled", true)
                settings.setBool("opt_memory_gc", true)
                settings.setBool("opt_img_enabled", true)
                settings.setInt("opt_img_quality", 85)
                settings.setInt("opt_img_max_dim", 1600)
                settings.setBool("opt_img_high_quality", false)
                settings.setBool("opt_img_res_limit", false)
                Utils.showToast("Configurações redefinidas com sucesso!")
                rebind()
            }
        }
        layout.addView(btnReset)
    }

    private fun createSwitch(
        ctx: Context,
        title: String,
        subtitle: String,
        key: String,
        defaultVal: Boolean,
        onCustomChange: ((Boolean) -> Unit)? = null
    ): CheckedSetting {
        return Utils.createCheckedSetting(
            ctx,
            CheckedSetting.ViewType.SWITCH,
            title,
            subtitle
        ).apply {
            isChecked = settings.getBool(key, defaultVal)
            setOnCheckedListener { checked ->
                settings.setBool(key, checked)
                onCustomChange?.invoke(checked)
            }
        }
    }

    private fun createSectionHeader(ctx: Context, title: String): TextView {
        return TextView(ctx).apply {
            text = title
            textSize = 12f
            setPadding(0, 16.dp, 0, 8.dp)
            alpha = 0.7f
        }
    }
}
