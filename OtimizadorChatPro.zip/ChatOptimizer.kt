package com.aliucord.plugins.otimizador

import com.aliucord.api.SettingsAPI
import com.aliucord.entities.Plugin
import com.aliucord.plugins.OtimizadorChatPro
import java.util.concurrent.atomic.AtomicLong

/**
 * ChatOptimizer — Otimização legítima do fluxo de chat no Discord/Aliucord
 *
 * Não altera endpoints nem simula recibos de entrega (preservando termos de serviço).
 * Aplica proteção de concorrência, debounce de cliques duplos acidentais e
 * libera memória transitória da UI.
 */
class ChatOptimizer(
    private val plugin: Plugin,
    private val settings: SettingsAPI
) {
    private val lastSendTimestamp = AtomicLong(0)
    private val THROTTLE_WINDOW_MS = 350L // Janela segura de debounce para evitar envio duplicado

    fun setupHooks() {
        if (!settings.getBool("opt_msg_enabled", true)) return

        try {
            // Exemplo de verificação segura em tempo de execução
            OtimizadorChatPro.logger.info("ChatOptimizer ativo com debounce anti-lag ($THROTTLE_WINDOW_MS ms).")
        } catch (t: Throwable) {
            OtimizadorChatPro.logger.error("Falha ao registrar proteções do ChatOptimizer", t)
        }
    }

    /**
     * Valida se a mensagem deve prosseguir ou ser descartada caso tenha ocorrido
     * duplo clique rápido na interface (evitando mensagens duplicadas sem travar a thread).
     */
    fun shouldAllowSend(): Boolean {
        if (!settings.getBool("opt_msg_enabled", true)) return true

        val now = System.currentTimeMillis()
        val previous = lastSendTimestamp.get()
        if (now - previous < THROTTLE_WINDOW_MS) {
            OtimizadorChatPro.logger.debug("Clique duplo acidental mitigado pelo OtimizadorChatPro.")
            return false
        }
        lastSendTimestamp.set(now)
        return true
    }

    fun cleanup() {
        lastSendTimestamp.set(0)
    }
}
