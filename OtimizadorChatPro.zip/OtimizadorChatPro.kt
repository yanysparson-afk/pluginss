package com.aliucord.plugins

import android.content.Context
import com.aliucord.Logger
import com.aliucord.Utils
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.plugins.otimizador.ChatOptimizer
import com.aliucord.plugins.otimizador.ImageOptimizer
import com.aliucord.plugins.otimizador.PluginSettings

/**
 * OtimizadorChatPro — Plugin oficial para Aliucord
 *
 * Responsável por:
 * 1. Otimizar a fluidez de envio de mensagens e prevenir duplicações acidentais.
 * 2. Redimensionar e comprimir imagens localmente em background com controle de memória.
 * 3. Prover um SettingsTab nativo e integrado para personalização completa.
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class OtimizadorChatPro : Plugin() {

    companion object {
        val logger = Logger("OtimizadorChatPro")
        lateinit var instance: OtimizadorChatPro
            private set
    }

    private var chatOptimizer: ChatOptimizer? = null
    private var imageOptimizer: ImageOptimizer? = null

    init {
        // Registra o painel de configurações na aba Plugins do Aliucord
        settingsTab = SettingsTab(
            PluginSettings::class.java,
            SettingsTab.Type.PAGE
        ).withArgs(settings)
    }

    override fun load(context: Context) {
        instance = this
        logger.info("Plugin OtimizadorChatPro carregado na memória.")
    }

    override fun start(context: Context) {
        try {
            logger.info("Iniciando otimizações do OtimizadorChatPro...")

            // Inicializa módulo de otimização de imagens (preserva e melhora o código inicial)
            imageOptimizer = ImageOptimizer(this, settings)
            imageOptimizer?.setupHooks()

            // Inicializa módulo de otimização do chat e envio
            chatOptimizer = ChatOptimizer(this, settings)
            chatOptimizer?.setupHooks()

            Utils.showToast("OtimizadorChatPro ativado com sucesso!")
        } catch (t: Throwable) {
            logger.error("Falha ao inicializar patches do OtimizadorChatPro", t)
        }
    }

    override fun stop(context: Context) {
        try {
            logger.info("Removendo todos os patches e limpando recursos...")
            patcher.unpatchAll()
            imageOptimizer?.cleanup()
            chatOptimizer?.cleanup()
            imageOptimizer = null
            chatOptimizer = null
        } catch (t: Throwable) {
            logger.error("Erro durante desativação do plugin", t)
        }
    }

    override fun unload(context: Context) {
        logger.info("Plugin OtimizadorChatPro descarregado.")
    }
}
