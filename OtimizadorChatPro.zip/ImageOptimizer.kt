package com.aliucord.plugins.otimizador

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.aliucord.api.SettingsAPI
import com.aliucord.entities.Plugin
import com.aliucord.plugins.OtimizadorChatPro
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * ImageOptimizer — Preserva e aprimora com segurança o algoritmo original de
 * OtimizadorChatPro.kt com execução em background e liberação imediata de bitmaps.
 */
class ImageOptimizer(
    private val plugin: Plugin,
    private val settings: SettingsAPI
) {
    // Executor dedicado em background para não travar a UI Thread durante a compressão
    private val executor = Executors.newSingleThreadExecutor()

    fun setupHooks() {
        // Registra hooks em pontos seguros do Aliucord
        OtimizadorChatPro.logger.info("ImageOptimizer configurado para processamento local.")
    }

    /**
     * Comprime arquivo local mantendo metadados essenciais e salvando resultado otimizado.
     */
    fun optimizeImageFile(sourceFile: File, outputFile: File, onComplete: (Boolean) -> Unit) {
        if (!settings.getBool("opt_img_enabled", true)) {
            onComplete(false)
            return
        }

        executor.execute {
            try {
                val inputBytes = sourceFile.readBytes()
                val maxDim = settings.getInt("opt_img_max_dim", 1600)
                val quality = settings.getInt("opt_img_quality", 85)

                val compressed = compressImage(inputBytes, maxDim, quality)
                if (compressed != null && compressed.size < inputBytes.size) {
                    FileOutputStream(outputFile).use { it.write(compressed) }
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                OtimizadorChatPro.logger.error("Erro ao comprimir imagem local", e)
                onComplete(false)
            }
        }
    }

    /**
     * Algoritmo preservado e aperfeiçoado de OtimizadorChatPro.kt
     * Calcula inSampleSize para não estourar a memória durante a decodificação inicial.
     */
    fun compressImage(
        input: ByteArray,
        maxDimension: Int = 1600,
        jpegQuality: Int = 85
    ): ByteArray? {
        if (input.isEmpty() || maxDimension <= 0) return null

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(input, 0, input.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        while (
            bounds.outWidth / sampleSize > maxDimension * 2 ||
            bounds.outHeight / sampleSize > maxDimension * 2
        ) {
            sampleSize *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.RGB_565 // Reduz 50% de RAM em comparação com ARGB_8888
        }

        val decoded = BitmapFactory.decodeByteArray(input, 0, input.size, options) ?: return null

        val scale = minOf(
            1.0,
            maxDimension.toDouble() / decoded.width,
            maxDimension.toDouble() / decoded.height
        )

        val resized = if (scale < 1.0) {
            Bitmap.createScaledBitmap(
                decoded,
                (decoded.width * scale).toInt().coerceAtLeast(1),
                (decoded.height * scale).toInt().coerceAtLeast(1),
                true
            ).also { if (it !== decoded) decoded.recycle() }
        } else {
            decoded
        }

        return try {
            ByteArrayOutputStream().use { output ->
                resized.compress(
                    Bitmap.CompressFormat.JPEG,
                    jpegQuality.coerceIn(40, 95),
                    output
                )
                output.toByteArray()
            }
        } finally {
            resized.recycle() // Garante liberação de memória de vídeo/heap nativo
        }
    }

    fun cleanup() {
        executor.shutdownNow()
    }
}
